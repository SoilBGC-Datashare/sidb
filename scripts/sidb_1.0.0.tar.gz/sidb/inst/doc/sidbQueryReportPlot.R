## ----setup--------------------------------------------------------------------
knitr::opts_chunk$set(
  eval = FALSE,
  collapse = TRUE,
  comment = "#>"
  )

## ----libraries----------------------------------------------------------------
# devtools::install_github("SoilBGC-Datashare/sidb/Rpkg")
# library(sidb)
# library(ggplot2)
# library(plyr)
# library(dplyr)

## ----prep---------------------------------------------------------------------
# # load data
# database <- loadEntries("~/sidb/data/")
# 
# # run "flatter" fx
# db <- flatterSIDB(database)
# 
# # join variables dataframes with initConditions
# vars.ic <- lapply(seq_along(database), function(i) left_join(db$vars[[i]], database[[i]][["initConditions"]]))
# names(vars.ic) <- names(database)
# 
# # remove NA columns from vars.ic
# vars.ic <- lapply(vars.ic, function(x) x[ ,!apply(is.na(x),2,all)])
# 
# # create df object of timeseries list
# ts.df <- do.call("rbind", db$timeseries)

## ----filter-------------------------------------------------------------------
# # add statistic column to entries missing it
# vars.dfl.mean <- lapply(vars.ic, function(x) {
#   if(is.null(x$statistic)) {
#     x$statistic = NA
#   } else {
#     x$statistic = x$statistic
#   }
#   return(x)
# })
# vars.dfl.mean <- lapply(vars.dfl.mean, function(x) {
#   x = x[which(x$statistic == "none" | is.na(x$statistic)),]
#   return(x)
# })

## ----subset, warning=FALSE----------------------------------------------------
# # list variables in vars.dfl by calling 'names' on each element of list and filtering to unique values
# sort(unique(unlist(lapply(vars.dfl.mean, function(x) names(x)))))
# 
# # first extract indices of studies with timeseries that match conditions
# ix.ls <- lapply(vars.dfl.mean, function(x) which(x$temperature >= 10 & x$temperature <= 20))
# 
# # then subset list with list of indices and convert to dataframe
# t.10.20.df <- plyr::rbind.fill(lapply(seq_along(vars.dfl.mean), function(i) vars.dfl.mean[[i]][ix.ls[[i]],]))
# 
# # join your subset of the variables dataframes with the corresponding timeseries
# t.10.20.df <- dplyr::left_join(t.10.20.df, ts.df, by="ID")

## ----plot1--------------------------------------------------------------------
# ggplot(t.10.20.df, aes(time, response, color=abs(latitude))) +
#   geom_path() +
#   scale_x_continuous(limits=c(0,300)) +
#   theme_bw() +
#   theme(panel.grid = element_blank())

## ----plot2--------------------------------------------------------------------
# # first filter based on moisture units, then plot
# filter(t.10.20.df, latitude >= 60) %>% filter(moisture.units == "percentFieldCapacity") %>%
#   ggplot(., aes(time, response, color=moisture)) +
#   geom_path() +
#   scale_x_continuous(limits=c(0,100)) +
#   theme_bw() +
#   theme(panel.grid = element_blank())

## ----plot3--------------------------------------------------------------------
# ggplot(t.10.20.df, aes(time, response, color=moisture)) +
#   geom_path() +
#   scale_x_continuous(limits=c(0,30)) +
#   scale_y_continuous(limits=c(0,1.3e+05)) +
#   scale_color_continuous(limits=c(0,100)) +
#   theme_bw() +
#   theme(panel.grid = element_blank())

